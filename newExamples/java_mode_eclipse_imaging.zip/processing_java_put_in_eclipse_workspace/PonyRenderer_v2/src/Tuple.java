
public class Tuple {
	public int elem0, elem1, elem2;
	
	public Tuple(){
	}
	
	public Tuple(int elem0, int elem1, int elem2){
		this.elem0 = elem0;
		this.elem1 = elem1;
		this.elem2 = elem2;
	}

}
